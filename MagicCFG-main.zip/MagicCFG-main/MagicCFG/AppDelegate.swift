//
//  AppDelegate.swift
//  MagicCFG
//
//  Created by Jan Fabel on 11.06.20.
//  Copyright © 2020 Jan Fabel. All rights reserved.
//

import Cocoa


@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {


    
    
   
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

