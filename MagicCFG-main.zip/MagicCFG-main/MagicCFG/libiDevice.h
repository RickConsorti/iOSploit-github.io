//
//  libiDevice.h
//  MagicCFG
//
//  Created by Jan Fabel on 02.10.20.
//  Copyright © 2020 Jan Fabel. All rights reserved.
//

#ifndef libiDevice_h
#define libiDevice_h

#include <stdio.h>

#endif /* libiDevice_h */
