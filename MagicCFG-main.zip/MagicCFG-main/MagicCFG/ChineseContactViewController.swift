//
//  ChineseContactViewController.swift
//  MagicCFG
//
//  Created by Jan Fabel on 29.07.20.
//  Copyright © 2020 Jan Fabel. All rights reserved.
//

import Cocoa

class ChineseContactViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    @IBAction func Go(_ sender: Any) {
        self.dismiss(sender)
    }
    
}
